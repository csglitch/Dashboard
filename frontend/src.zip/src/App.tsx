import { createSignal, type Component } from 'solid-js';

import { Router, Route } from 'solid-app-router';
import logo from './logo.svg';
import styles from './App.module.css';
import SignUpForm from './form/signup';
import './App.scss'
import LoginForm from './form/login';
// import LoginForm from './form/login';

function App(){
  const[isSignup,setIsSignup]= createSignal(false);

  const toggleFormMode=()=>{
    setIsSignup(!isSignup());
  };
  return (
    <div class={styles.App}>
     {isSignup() ? <SignUpForm/>:<LoginForm/>}
     <button onClick={toggleFormMode}>
       {isSignup() ? "Already have an account? Login" : "New user? Sign Up"}
     </button>
  
        
   
   </div>
   
  );
};

export default App;
