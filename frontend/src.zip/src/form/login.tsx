

import { createSignal } from 'solid-js';
import './login.scss';

function LoginForm() {
  const [loginData, setloginData] = createSignal({
    email: "",
    password: "",
  });
 
  const handleFormSubmit = (e: Event) => {
    e.preventDefault();
    if (!/^[\w.%+-]+@bajajfinserv\.in$/.test(loginData().email)) {
        console.error("Please enter a valid email address with the domain @bajajfinserv.in.");
        return; 
      }
console.log('Login Form Submitted', loginData());
    };
 

  return (
    <div class="form_wrapper">
  <div class="form_container">
    <div class="title_container">
      <h2>Login</h2>
    </div>
    <div class="row clearfix">
      <div class="">
    <form onSubmit={handleFormSubmit}>
    <div class="input_field"> 
           
      <input
        type="email"
        placeholder="Email"
        value={loginData().email}
        onInput={(e) => setloginData({ ...loginData(), email: e.target.value })}
                  required />
            {!/^[\w.%+-]+@bajajfinserv\.in$/.test(loginData().email)&& (
              <p class="error">Please enter a valid email address with the domain @bajajfinserv.in</p>
            )}
    </div>
      <input
        type="password"
        placeholder="Password"
        value={loginData().password}
        onChange={(e) => setloginData({ ...loginData(), password: e.target.value })}
      required/>
   
       <input class="button" type="submit" value="Login" />
          
    </form>
    </div>
    
    </div>
 
    </div>
  </div>
  );
}

export default LoginForm;
