import { createSignal } from 'solid-js';
import './signup.scss';

import { Link } from 'solid-app-router';

function SignUpForm() {
  const [formData, setFormData] = createSignal({
    email: "",
    password: "",
    retypepassword: "",
    lastname: "",
    firstname:"",
   
    phonenumber: "",
    
  });

  const handleSubmit = (e:Event) => {
    e.preventDefault();
    if (formData().password !== formData().retypepassword) {
      console.error("Passwords do not match!");
      return; 
    }
    // if (!formData().agreeTerms) {
    //   console.error("Please agree to the terms.");
    //   return;}
      if (!/^[\w.%+-]+@bajajfinserv\.in$/.test(formData().email)) {
        console.error("Please enter a valid email address with the domain @bajajfinserv.in.");
        return; // Prevent form submission if email domain is invalid
      }
    
    console.log('Signup Form submitted:', formData());
  };
  const validatePhoneNumber = (value: string) => {
    const phoneNumberRegex = /^\d{10}$/; // Matches exactly 10 digits
    return phoneNumberRegex.test(value);
  };
  const validateNameLength = (value: string, minLength: number, maxLength: number) => {
    return value.length >= minLength && value.length <= maxLength;
  };

  return (
  
    <div class="form_wrapper">
  <div class="form_container">
    <div class="title_container">
      <h2>Sign Up</h2>
    </div>
    <div class="row clearfix">
      <div class="">
        <form onSubmit={handleSubmit}>
        <div class="row clearfix">
            <div class="col_half">
              <div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
                <input type="text" name="name" placeholder="First Name" 
                 value={formData().firstname}
                 onInput={(e) => setFormData({ ...formData(), firstname: e.target.value })} required
                  />
                   {!validateNameLength(formData().firstname, 2, 20) && (
                <p class="error">First name must be between 2 and 20 characters.</p>
              )}
              </div>
            </div>
            <div class="col_half">
              <div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
                <input type="text" name="name" placeholder="Last Name" 
                 value={formData().lastname}
                 onInput={(e) => setFormData({ ...formData(), lastname: e.target.value })} required />
                  {!validateNameLength(formData().lastname, 2, 20) && (
                <p class="error">Last name must be between 2 and 20 characters.</p>
              )}
              </div>
            </div>
          </div>
          <div class="input_field"> 
            <input type="email" 
            name="email"
            placeholder="Email" 
            value={formData().email}
                  onInput={(e) => setFormData({ ...formData(), email: e.target.value })}
                  required />
            {!/^[\w.%+-]+@bajajfinserv\.in$/.test(formData().email)&& (
              <p class="error">Please enter a valid email address with the domain @bajajfinserv.in</p>
            )}
          </div>
          <div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
            <input type="text" name="phonenumber" placeholder="Phone number" 
             value={formData().phonenumber}
             onInput={(e) => setFormData({ ...formData(), phonenumber: e.target.value })} required />
               {!validatePhoneNumber(formData().phonenumber) && (
            <p class="error">Please enter a valid 10-digit phone number.</p> )}
          </div>
          <div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
            <input type="password" name="password" placeholder="Password" 
             value={formData().password}
             onInput={(e) => setFormData({ ...formData(), password: e.target.value })} required />
          </div>
          <div class="input_field"> <span><i aria-hidden="true" class="fa fa-lock"></i></span>
            <input type="password" name="password" placeholder="Re-type Password" 
             value={formData().retypepassword}
             onInput={(e) => setFormData({ ...formData(), retypepassword: e.target.value })} required />
              {formData().password !== formData().retypepassword && (
            <p class="error">Passwords do not match.</p>
          )}
          </div>
        
            
            
            {/* <div class="input_field checkbox_option">
            	<input type="checkbox" 
              name="agreeTerms"
              checked={formData().agreeTerms}
              id="cb1"
              onChange={(e) => setFormData({ ...formData(), agreeTerms: e.target.checked })}
              required/>
    			<label for="cb1">I agree with terms and conditions</label>
          {!formData().agreeTerms && (
            <p class="error">Please agree to the terms!</p>
          )}
            </div> */}
          
          <input class="button" type="submit" value="Register" />
          
        </form>
      </div>
    </div>
  </div>
  
</div>


    // <div class='Form'>
    // <form onSubmit={handleSubmit}>
    //   <div>
    //     <label for="Frist Name">First Name:</label>
    //     <input
    //       type="text"
    //       id="firstname"
    //       value={formData().firstname}
    //       onInput={(e) => setFormData({ ...formData(), firstname: e.target.value })}
    //       required
    //     />
    //   </div>
    //   <div>
    //     <label for="Last Name">Last Name:</label>
    //     <input
    //       type="text"
    //       id="lastname"
    //       value={formData().lastname}
    //       onInput={(e) => setFormData({ ...formData(), lastname: e.target.value })}
    //       required
    //     />
    //   </div>
    //   <div>
    //     <label for="email">Email:</label>
    //     <input
    //       type="email"
    //       id="email"
    //       value={formData().email}
    //       onInput={(e) => setFormData({ ...formData(), email: e.target.value })}
    //       required
    //     />
    //   </div>
    //   <div>
    //     <label for="password">Password:</label>
    //     <input
    //       type="password"
    //       id="password"
    //       value={formData().password}
    //       onInput={(e) => setFormData({ ...formData(), password: e.target.value })}
    //       required
    //     />
    //   </div>
    //   <div>
    //     <label for="Mobile No.">Mobile No.:</label>
    //     <input
    //       type="text"
    //       id="firstname"
    //       value={formData().firstname}
    //       onInput={(e) => setFormData({ ...formData(), firstname: e.target.value })}
    //       required
    //     />
    //   </div>
    //   <button type="submit">Sign Up</button>
    // </form>
   
  );
}

export default SignUpForm;




